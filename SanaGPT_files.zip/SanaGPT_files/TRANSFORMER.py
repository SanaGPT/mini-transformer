import torch as t
import torch.nn as n
import math


class Embeddingclass(n.Module):
    def __init__(self, d_model, word_length):
        super().__init__()

        self.dmodel = d_model
        self.embedding = n.Embedding(word_length, d_model)

    def forward(self, x):
        return self.embedding(x) *math.sqrt(self.dmodel)
    

class PositionalEncoding(n.Module):
    def __init__(self, d_model, seq_length = 512):
        super().__init__()
        self.dmodel = d_model
        pt = t.arange(seq_length, dtype= t.float32).unsqueeze(1)
        dindex = t.arange(d_model, dtype = t.float32)
        pe = t.zeros(seq_length, d_model, dtype= t.float32)
        divterm = 10000.0 ** ((2 * (dindex // 2)) / d_model)

        pe[:, 0::2] = t.sin(pt / divterm[0::2])
        pe[:, 1::2] = t.cos(pt / divterm[1::2])

        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:, :x.size(1) , :]

'''        
class Attention(n.Module):
    def __init__(self, dmodel, dk = 64):
        super().__init__()

        self.dmodel = dmodel
        self.dk = dk
        self.wq = n.Linear(dmodel, dk)
        self.wk = n.Linear(dmodel, dk)
        self.wv = n.Linear(dmodel, dk)
        self.linearout = n.Linear(dk, dmodel)

    def forward(self, x):
        q = self.wq(x)
        k =self.wk(x)
        v =self.wv(x)

        score = t.matmul(q, k.transpose(-2, -1))
        score = score / math.sqrt(self.dk)

        weights = t.softmax(score, dim = -1)

        content = t.matmul(weights, v)

        output = self.linearout(content)

        return output, v
'''

class CasualMultiHeadAttention(n.Module):
    def __init__(self, dmodel,headnum = 8, dk = 64):
        super().__init__()
        self.dmodel = dmodel
        self.dk = dk
        self.headnum = headnum
        self.linearout = n.Linear(dk * headnum, dmodel)
        self.wq = n.Linear(dmodel, dk * headnum)
        self.wk = n.Linear(dmodel, dk * headnum)
        self.wv = n.Linear(dmodel, dk * headnum)
    
    def mask_generator(self, seqlen):
        mask = t.triu(t.ones(seqlen, seqlen), diagonal = 1).bool()
        return mask

    def forward(self, x, mask = None):
        q = self.wq(x)
        v = self.wv(x)
        k = self.wk(x)
        
        a, b, _ = x.shape

        q = q.reshape(a,b,self.headnum,self. dk)
        k = k.reshape(a,b,self.headnum,self. dk)
        v = v.reshape(a,b,self.headnum,self. dk)

        q = q.transpose(1,2)
        k = k.transpose(1,2)
        v = v.transpose(1,2)
        
        score = t.matmul(q, k.transpose(-1, -2)) / math.sqrt(self.dk)

        if mask is None:
            mask = self.mask_generator(b)
            mask = mask.to(x.device)
        score = score.masked_fill(mask.unsqueeze(0).unsqueeze(0), float('-inf'))

        weight = t.softmax(score, dim = -1)
        content = t.matmul(weight, v)

        content = content.transpose(1,2).contiguous().view(a, b, self.headnum * self.dk)

        result = self.linearout(content)

        return result, weight

class FeedForward(n.Module):
    def __init__(self, dmodel, dff = None, dropoutp = 0.1):
        super().__init__()
        if dff is None:
            dff = dmodel * 4
        self.dropout = dropoutp
        self.model = n.Sequential(n.Linear(dmodel, dff), n.GELU(), n.Dropout(p=dropoutp), n.Linear(dff, dmodel), n.Dropout(p=dropoutp))
    
    def forward(self, x):
        return self.model(x)
    
class LayerNormalization(n.Module):
    def __init__(self, dmodel, eps = 1e-6):
        super().__init__()
        self.eps = eps
        self.gamma = n.Parameter(t.ones(dmodel))
        self.beta = n.Parameter(t.zeros(dmodel))

    def forward(self, x):
        mean = t.mean(x, dim= -1, keepdim= True)
        std = t.std(x, dim= -1, keepdim= True)
        return self.gamma * (x - mean) / (std + self.eps) + self.beta
