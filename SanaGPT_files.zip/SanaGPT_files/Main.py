import torch as t
import torch.nn as n
import torch.optim as optim
import torch.nn.functional as f
import torch.distributions as dist
import math 
import os
from corpus import *
from TRANSFORMER import *

corpus = afghan



words = set()
for sentence in corpus:
    words.update(sentence.split())
toyds = {word : idx for idx,word in enumerate(sorted(words))}
dmodel = 256
num_epoches = 50
learning_rate = 1e-3
device = t.device('cuda' if t.cuda.is_available() else 'cpu')
batch_size = 4

def tokening(dataset,sentences : str = None, corpusds = None):
    if corpusds is not None:
        sentense = []
        for sentence in corpusds:
            words = []
            for word in sentence.split():
                words.append(dataset[word])
            wor = t.tensor(words)
            sentense.append(wor)
        result = sentense

    else:
        words = []
        for word in sentences.split():
            words.append(dataset[word])
        result = t.tensor(words)

    return result

invertedds = {}

for word, idx in toyds.items():
    invertedds[idx] = word

class TransformerLM(n.Module):
    def __init__(self, vocab_size,dmodel = dmodel):
        super().__init__()
        
        self.embedding = Embeddingclass( d_model= dmodel, word_length= vocab_size)
        self.PositionalEncoding = PositionalEncoding(seq_length= 512, d_model= dmodel)
        self.CMHA = CasualMultiHeadAttention(dmodel= dmodel)
        self.ff = FeedForward(dmodel= dmodel)
        self.layernorm = LayerNormalization(dmodel= dmodel)
        self.out = n.Linear(dmodel, vocab_size)

    def forward(self, x):
        x = self.embedding(x)
        x = self.PositionalEncoding(x)

        attention_output, _ = self.CMHA(x)
        x = self.layernorm(x + attention_output)

        ffn_output = self.ff(x)
        x = self.layernorm(x + ffn_output)

        logits = self.out(x)
        return logits
    
    def get_next_token_probs(self, input_seq):
        result = self.forward(input_seq)
        nexttlogit = result[:, -1, :]
        nexttprobs = f.softmax(nexttlogit, dim=-1)
        return nexttprobs
    
    def sample_next_token(self, inputseq):
        probabilities = self.get_next_token_probs(inputseq)
        distribution = dist.Categorical(probabilities)
        sampled = distribution.sample()
        logprob = distribution.log_prob(sampled)
        return sampled, logprob



sentence = 'I love'

def chat(ds, inverteddset, sentence):
    model = TransformerLM(vocab_size= len(ds))

    token = tokening(ds, sentence).unsqueeze(0)

    logits = model(token)

    last_logits = logits[0, -1]

    prediction_tensor = t.argmax(last_logits).item()

    predict = inverteddset[prediction_tensor]

    return predict


def corpus_determining(corpus):
    tokenized_corpus = tokening(toyds, corpusds=corpus)
    padded_corpus = t.nn.utils.rnn.pad_sequence(tokenized_corpus, batch_first= True, padding_value=toyds['<PAD>'])
    dataset = t.utils.data.TensorDataset(padded_corpus)
    dataloader = t.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle= True)
    vocabsize = len(toyds)
    model = TransformerLM(vocab_size=vocabsize, dmodel=dmodel).to(device)
    criterionmodel = n.CrossEntropyLoss(ignore_index=toyds['<PAD>'])
    optimizermodel = t.optim.Adam(model.parameters(), lr= learning_rate)

    if os.path.exists("transformer_checkpoint.pth"):
        checkpoint = t.load("transformer_checkpoint.pth", map_location=device)
        model.load_state_dict(checkpoint["model_state"])
        optimizermodel.load_state_dict(checkpoint["optimizer_state"])
        print("✅ Loaded checkpoint from transformer_checkpoint.pth")
    else:
        print("⚠️ No checkpoint found, starting fresh")


    return model, criterionmodel, optimizermodel, dataloader, vocabsize

model, criterionmodel , optimizermodel, dataloader, vocabsize = corpus_determining(corpus)
max_len = len(toyds)

for epoch in range(num_epoches):
    model.train()
    total_loss = 0
    for batch in dataloader:
        data = batch[0].to(device)
        inputs = data[:, :-1].contiguous()
        targets = data[:, 1:].contiguous()
        logits = model(inputs)
        loss = criterionmodel(logits.view(-1, vocabsize), targets.view(-1))
        optimizermodel.zero_grad()
        loss.backward()
        optimizermodel.step()
        total_loss += loss.item()
    print(f"Epoch {epoch+1}, Loss: {total_loss / len(dataloader):.4f}")


    t.save({
        "model_state": model.state_dict(),
        "optimizer_state": optimizermodel.state_dict(),
        "vocab": toyds
    }, "transformer_checkpoint.pth")
    print("💾 Checkpoint saved")

'''
def text_generation(model, prompt, ds, inverted, max_lenght = max_len):
    model.eval()
    generated = tokening(dataset=ds, sentences=prompt).unsqueeze(0).to(device)
    log_probs = []

    for _ in range(max_lenght):
        logit = model(generated)  
        next_token_logit = logit[0, -1]
        probs = t.softmax(next_token_logit, dim=-1)
        next_token = t.multinomial(probs, num_samples=1)
        log_prob = t.log(probs[next_token])
        log_probs.append(log_prob)

        generated = t.cat([generated, next_token.unsqueeze(0)], dim= 1)
        if next_token.item() == ds['<PAD>']:
            break

    result = [inverted[token.item()] for token in generated[0]]
    return ' '.join(result), log_probs
'''

def rLHF(sequence : str):
    print(f"Generated sequence: {sequence}")
    try:
        feedback = float(input('Feedback on the sequence (float): '))
        return feedback
    except ValueError:
        print('Please enter a valid number.')
        return 0.0
    
def chat_generation( prompt , model = model, ds = toyds, inverted = invertedds, max_tokens=15):
    model.eval()
    generated = tokening(dataset=ds, sentences=prompt).unsqueeze(0).to(device)
    reply_tokens = []

    for _ in range(max_tokens):
        logits = model(generated)
        next_token_logits = logits[0, -1]
        probs = t.softmax(next_token_logits, dim=-1)
        next_token = t.multinomial(probs, num_samples=1)

        word = inverted[next_token.item()]
        if word in ["USER:", "<PAD>" "<EOS>"]:   # stop when new user turn starts
            break

        reply_tokens.append(word)
        generated = t.cat([generated, next_token.unsqueeze(0)], dim=1)

    return " ".join(reply_tokens), probs

def training(prompt,ds = toyds , model = model, optimizer = optimizermodel, iteration = 12, inverted = invertedds):
    model.train()
    for i in range(iteration):
        tokens = tokening(dataset=ds, sentences= prompt)
        tokens = tokens.unsqueeze(0).to(device)
        sampled, prob = chat_generation(prompt)
        reward = rLHF(sampled)
        loss = -(prob * reward).mean()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        print(f"Iteration {i+1}: Word '{sampled}' | Reward: {reward} | Loss: {loss.item():.4f}")

extracorpus = []

def dynamic_learning(prompt : str, words : dict, corpus : list = extracorpus):
    for i in  '.,-_':
        if i in prompt:
            prompt = prompt.replace(i, ' ')
    
    sentence = prompt.split(' ')

    wordindex = list(words.values())[-1]
    for word in sentence:
        if word not in words.keys():
            words[word] = wordindex + 1
            wordindex += 1  

    prompt = f'USER : {prompt} BOT :'
    response , _ = chat_generation(prompt=prompt)
    prompt = f'USER : {prompt} BOT : {response}'
    corpus.append(prompt)

جمله = "من کیک دوست دارم"

prot = f'USER : {جمله} BOT :'
print(training(prot, model=model, ds=toyds,inverted= invertedds))
dynamic_learning(prompt=جمله, words = toyds, corpus=corpus)

t.save({
        "model_state": model.state_dict(),
        "optimizer_state": optimizermodel.state_dict(),
        "vocab": toyds
    }, "transformer_checkpoint.pth")
print("💾 Checkpoint saved")
